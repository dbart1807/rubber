/*
 * ErrorMsg.h
 *
 *  Created on: Feb 13, 2013
 *      Author: nek3d
 */

#ifndef ERRORMSG_H_
#define ERRORMSG_H_




#endif /* ERRORMSG_H_ */
