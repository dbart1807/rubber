bam.parselengths <-
function( bamfile , brks=c(0,70,140,200) , cores="max" ){
	options(scipen=99999)

	numbreaks<-length(brks)
	if(numbreaks==1){stop("need two or more breakpoints")}


	library(parallel)
	library(tools)
	if(cores=="max"){cores=detectCores()-1}
	if(cores > numbreaks){ cores <- numbreaks }

	# make sure input is only 1 file
	if(length(bamfile) > 1){stop("bam.parselengths can only take 1 file")}

	ext<-file_ext(bamfile)
	fragname<-basename(removeext(bamfile))
	
	brknames<-formatC(brks,width=nchar(brks[numbreaks]),format="d",flag="0")
	brknames[which(is.infinite(brks))]<-999999999999

	# parse fragments by length
	outnames<-unlist(mclapply(1:(numbreaks-1),function(i){
		subfragname<-paste0(fragname,"_",brknames[i],"-",brknames[i+1],".bam",sep="")
		system(paste("samtools view -h",bamfile,"| awk '{if($9 >=",brks[i],"|| $9 <=",-brks[i]," ) {print $0} else if($9==\"\") print $0 }' | awk '{if ($9 >=",-brks[i+1],"&& $9 <= ",brks[i+1],") { print $0} else if($9==\"\") print }' | samtools view -bS - >", subfragname))
		return(subfragname)
	},mc.cores=cores))
	return(outnames)
}
