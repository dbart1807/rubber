bed.2.bg <-
function( bedfiles , score="size" ){
	bednames<-basename(removeext(bedfiles))
	outnames<-paste0(bednames,".cfbg")
	for(i in 1:length(bedfiles)){
		system( paste0("awk '{a=int(($2+$3)/2+0.5); $4=$3-$2; $2=a; $3=a+1;print}' OFS='\t' ",bedfiles[i]," | sort -k1,1 -k2,2n > ",outnames[i]) )
	}
	return(outnames)
}
