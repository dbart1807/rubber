bed.liftover <- function( beds, chainfile, suffix , cores="max" ){
	
	library(parallel)
	library(gtools)
	numbeds <- length(beds)
	

	if(cores=="max"){cores=detectCores()-1}
	if( cores > numbeds ){ cores <- numbeds }

	exts <- file_ext( beds )
	bednames <- basename(removeext(beds))
	outnames <- paste0( bednames, suffix, ".", exts)
	unmapped <- paste0( bednames, "_unmapped", ".", exts)

	statuses <- mclapply( 1:numbeds, function(x){

		system( paste( "liftOver", beds[x], chainfile, outnames[x], unmapped[x] ) )

	}, mc.cores=cores, mc.preschedule=FALSE)

	return(outnames)

}