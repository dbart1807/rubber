bed.split.meta <-
function( bed, metasize, windowsize, flank, covbedname, start=2, stop=3 ){

	options(scipen=99999)
	library(parallel)

	bedrows<-nrow(curbed)
	bedcols<-ncol(curbed)

	numwindows<-metasize/windowsize
	numflankwindows<-flank/windowsize
	leftwinstarts<-0:(numflankwindows-1) * windowsize - flank
	leftwinends<-1:numflankwindows * windowsize - flank
	rightwinstarts<-0:(numflankwindows-1) * windowsize
	rightwinends<-1:numflankwindows * windowsize
	genesizes<-curbed[,stop]-curbed[,start]
	sizecos<-genesizes/metasize
	genewinstarts<-mclapply(1:bedrows, function(x) curbed[x,start] + 0:(numwindows-1) * windowsize * sizecos[x], mc.cores=detectCores())
	genewinends<-mclapply(1:bedrows, function(x) curbed[x,start] + 1:numwindows * windowsize * sizecos[x], mc.cores=detectCores())
	genewinstarts<-mclapply(genewinstarts,round,mc.cores=detectCores())
	genewinends<-mclapply(genewinends,round,mc.cores=detectCores())

	covbed<-data.frame(
		"V1"=rep(curbed[,1],each=numwindows+numflankwindows*2),
		"V2"=format(unlist(lapply(1:bedrows,function(x){ c(leftwinstarts+curbed[x,start],genewinstarts[[x]],rightwinstarts+curbed[x,stop]) } )),scientific=F,trim=T),
		"V3"=format(unlist(lapply(1:bedrows,function(x){ c(leftwinends+curbed[x,start], genewinends[[x]],rightwinends+curbed[x,stop]) } )),scientific=F,trim=T),
		"V4"=1:(bedrows*(numwindows+numflankwindows*2))
	)

	write.tsv(covbed,file=covbedname)
	system(paste("sort -k1,1 -k2,2n -k3,3n",covbedname,"-o",covbedname))
	covbedorder<-as.numeric(readLines(pipe(paste("cut -f 4",covbedname))))
	return(covbedorder)


}
