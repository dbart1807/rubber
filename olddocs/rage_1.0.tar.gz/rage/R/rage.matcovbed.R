rage.matcovbed <- function(covbed , bed ){

  #as.numeric(readLines(pipe(paste("bedtools coverage -a",bed,"-b",covbed," | sort -k1,1 -k2,2n -k3,3n | cut -f 4"))))
  as.numeric(readLines(pipe(paste("bedtools coverage -a",bed,"-b",covbed," | sort -k4,4n | cut -f 5"))))

}
