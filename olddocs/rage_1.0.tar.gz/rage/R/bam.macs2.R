bam.macs2 <- function ( treatmentFiles , controlFiles=NULL , genomeSize = "hs" , sampleName = NULL , callsummits = TRUE , qvalue = 0.01 , inputformat = "BAMPE" , verbosity = 3 ){
	
	# create output name string
	if( is.null( sampleName ) ){ sampleName = basename( removeext( treatmentFiles[1] ) ) }
	sampleName <- paste0( sampleName , "_" , tolower(inputformat) , "_fdr" , 100*qvalue , if(callsummits){"_summits"} )
	
	print(paste(
			"macs2 callpeak -t",
			paste( treatmentFiles, collapse=" " ),
			if( is.null( controlFiles ) == FALSE ) { paste( "-c", paste( controlFiles, collapse=" ") ) },
			"-n",sampleName,
			"-g",genomeSize,
			if(callsummits){ "--call-summits" },
			"-q",qvalue,
			"-f",inputformat,
			#"--outdir",outdir,
			"--verbose",3,
			"-B"
	))

	exitstatus <- system(
		paste(
			"macs2 callpeak -t",
			paste( treatmentFiles, collapse=" " ),
			if( is.null( controlFiles ) == FALSE ) { paste( "-c", paste( controlFiles, collapse=" ") ) },
			"-n",sampleName,
			"-g",genomeSize,
			if(callsummits){ "--call-summits" },
			"-q",qvalue,
			"-f",inputformat,
			#"--outdir",outdir,
			"--verbose",3,
			"-B"
		)
	)

	np.2.bed( paste0( sampleName, "_peaks.narrowPeak" ) )

	print( exitstatus )
	
}