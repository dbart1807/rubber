bed.merge <-
function( bedfile, flank=0, operation="none"){
    library(tools)
    ext<-file_ext(bedfile)
    if(flank==0){suffix=""}
    else{suffix=flank}
    if(operation=="none"){moreargs=""}
    else{
	suffix=c(suffix,operation)
	moreargs=c("-scores",operation)
    }
    
    outname<-paste(basename(removeext(bedfile)),"_merged",suffix,".",ext,sep="")
    
    system(paste("bedtools merge -d",flank,moreargs,"-i",bedfile,">",outname))
    return(outname)
}
