fastq.bt <-
function( read1files , indexfile , qvals=NULL , colorspace=FALSE , read2files=NULL , cores="max" , input="-q", q=10, makebam = TRUE , makebed = TRUE , chunkmbs=64){
	
	library(parallel)
	if(cores=="max"){cores<-detectCores()-1}

	read1names<-basename(removeext(read1files))
	
	if(is.null(read2files)){
		paired=FALSE
		outnames<-paste(basename(removeext(read1files)),".sam",sep="")
	} else{
		paired=TRUE
		outnames<-paste(basename(removeext(read1files)),".sam",sep="")
	}
	
	for(i in 1:length(read1files)){


		cat(read1names[i],": aligning to genome\n")
		if(paired==TRUE){
			system(paste(
				"bowtie",
				"-S",
				"--chunkmbs",chunkmbs,
				"-p",cores,
				if(colorspace){"-C"},
				input,
				indexfile,
				"-1",read1files[i],
				"-2",read2files[i],
				outnames[i]
			))
		}
		else{
			print(paste(
				"bowtie",
				"-S",
				"--chunkmbs",chunkmbs,
				"-p",cores,
				if(colorspace){"-C"},
				if(is.null(qvals)==FALSE){ "-Q" },
				if(is.null(qvals)==FALSE){ qvals[i] },
				input,
				indexfile,
				read1files[i],
				outnames[i]
			))
			system(paste(
				"bowtie",
				"-S",
				"--chunkmbs",chunkmbs,
				"-p",cores,
				if(colorspace){"-C"},
				if(is.null(qvals)==FALSE){ "-Q" },
				if(is.null(qvals)==FALSE){ qvals[i] },
				input,
				indexfile,
				read1files[i],
				outnames[i]
			))
		}
	}

	if(cores > length(read1files)) { cores <- length(read1files) }
	if(makebam) { outnames<-unlist(mclapply(outnames,sam.2.bam,mc.cores=cores,q=q)) }
	if(makebed) { outnames<-unlist(mclapply(outnames,bam.2.bed,if(paired){paired=TRUE} else{paired=FALSE},mc.cores=cores))}

	return(outnames)
}
