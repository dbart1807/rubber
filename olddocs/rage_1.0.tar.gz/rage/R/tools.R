filelines <-
function( filename ){
	as.numeric(readLines(pipe(paste("wc -l",filename,"| awk '{print $1}'"))))
}
files2 <-
function( cmd ){
	readLines(pipe(paste("ls -d",cmd)))
}
files <-
function( x,...){
	parts<-(unlist(strsplit(x,"/")))
	#cat("parts",parts,"\n")
	if(length(parts)>1){
		pth<-paste(parts[1:length(parts)-1],collapse="/")
	}
	else{
		pth="."
	}
	#cat("pth",pth,"\n")
	nm<-parts[length(parts)]
	#cat("name",nm,"\n")
	if(length(parts)>1){
		list.files(pattern=glob2rx(nm),path=pth,full.names=TRUE, ... )
	}
	else{
		list.files(pattern=glob2rx(nm), ... )
	}
}
findfiles <-
function( string, path="." ){
	return(readLines(pipe(paste("find ",path," -name '",string,"'",sep=""))))
}

get.file.extensions <-
function( filenames){
	for(i in 1:length(filenames)){
		namevector<-unlist(strsplit(filenames[i],"\\."))
		filenames[i]<-namevector[length(namevector)]
	}
	filenames
}
gunzip <- function( gzfiles, cores="max"){
	library(parallel)
	numfiles<-length(gzfiles)
	if(cores=="max"){cores <- detectCores()-1}
	if(cores>numfiles){cores <- numfiles}
	outnames<-removeext(gzfiles)
	es<-unlist(mclapply(gzfiles, function(x) system(paste("gunzip",x)) , mc.cores=cores))
	return(outnames)
}
getfullpaths <-
function( paths ){
	unlist(lapply(1:length(paths), function(x) system(paste("readlink -f",paths[x]),intern=TRUE) ))
}
getgenomefile <-
function( genome){
	if(genome=="b73v2"){chromfile=paste(datapath,"b73v2/b73v2.chrom.sizes",sep="")}
	if(genome=="dm3"){chromfile=paste(datapath,"dm3/dm3.chrom.sizes",sep="")}
	if(genome=="hg19"){chromfile=paste(datapath,"hg19/hg19.chrom.sizes",sep="")}
	if(genome=="hg18"){chromfile=paste(datapath,"hg18/hg18.chrom.sizes",sep="")}
	if(genome=="saccer3"){chromfile=paste(datapath,"saccer3/saccer3.chrom.sizes",sep="")}
	if(genome=="mm10"){chromfile=paste(datapath,"mm10/mm10.chrom.sizes",sep="")}
    return(chromfile)
}
getgtf <-
function( genome){
	if(genome=="hg19"){indexfile=paste(datapath,"hg19/igenome/Annotation/Genes/genes.gtf",sep="")}
        return(indexfile)
}
get.prefix <-
function( names,separator){
	for(i in 1:length(names)){
		names[i]<-unlist(lapply(strsplit(names[i],separator),"[",1))
	}
}
get.suffix <-
function( names,separator){
	for(i in 1:length(names)){
		stringvec<-unlist(strsplit(names[i],separator))
		names[i]<-stringvec[length(stringvec)]
	}
	names
}

gettindex <-
function( genome){
	if(genome=="hg19"){indexfile=paste(datapath,"hg19/tophatindex/genes",sep="")}
        return(indexfile)
}
read.fmat <-
function( mat, ... ){
	as.matrix(read.table(mat,stringsAsFactors=FALSE,sep="\t",row.names=1, ... ))
}
read.mat <-
function( mat, ... ){
	data.matrix(read.table(mat,stringsAsFactors=FALSE,sep="\t",row.names=1, ... ))
}
read.tsv <-
function( tsv, ... ){
	read.table(tsv,stringsAsFactors=FALSE,sep="\t", ... )
}
removeext <-
function( filenames ){
	filenames<-as.character(filenames)
	for(i in 1:length(filenames)){
		namevector<-unlist(strsplit(filenames[i],"\\."))
		filenames[i]<-paste(namevector[1:(length(namevector)-1)],collapse=".")
	}
	filenames
}
remove.header <-
function( filename ){
	library(tools)
	ext<-file_ext(filename)
	shortname<-basename(removeext(filename))
	outname<-paste(shortname,"_rh.",ext,sep="")
	system(paste("tail -n +2",filename,">",outname))
	system(paste("mv",outname,filename))
	outname<-basename(filename)
	return(outname)
}
remove.prefix <-
function( names,prefix){
	for(i in 1:length(names)){
		names[i]<-unlist(strsplit(names[i],prefix))[2]
	}
	names
}
remove.suffix <-
function( names,suffix){
	for(i in 1:length(names)){
		names[i]<-unlist(strsplit(names[i],suffix))[1]
	}
	names
}

renamefiles <-
function( filelist, pattern="", replacement=""){
	if(pattern==""){stop("YOU MUST SPECIFY 'pattern'\n")}
	filenames<-basename(filelist)
	outnames<-gsub(pattern,replacement,filenames)
	nametab<-data.frame("before"=filenames,"after"=outnames,stringsAsFactors=FALSE)
	print(nametab)
	for(i in 1:length(filelist)){
		cat("renaming ",filenames[i]," to ",outnames[i],"\n",sep="")
		system(paste("mv",filelist[i],outnames[i]))
	}
}
rotcol <-
function( vec){ vec[,rot(ncol(vec))] }
rotlist <-
function( l ){lapply(c(2:length(l),1),function(x) l[[x]] ) }
rot <-
function( x){(1:x %% x) +1}
rotrow <-
function( vec){ vec[rot(nrow(vec)),] }
rotvec <-
function( vec){ vec[rot(length(vec))] }
hostname<-Sys.info()["nodename"]
if(hostname %in% c("genome","chrom1","chrom2","chrom3","chrom4","chrom5")){
    datapath<-"/data/"
}
if(grepl("spear",hostname)==TRUE){datapath<-"/lustre/maize/home/dlv04c/data/"}
if(grepl("submit",hostname)==TRUE){datapath<-"/lustre/maize/home/dlv04c/data/"}
if(grepl("medicine",hostname)==TRUE){datapath<-"/lustre/maize/home/dlv04c/data/"}

#prevent scientific notation
options(scipen=100000000)

uniquefilename <-
function( filename ){
	library(tools)
	if(grepl("\\.",basename(filename))==TRUE){
		ext<-paste(".",file_ext(filename),sep="")
	} else{ ext="" }
	suffixes<-c("",paste("_",1:100,sep=""))
	filenames<-paste(removeext(filename),suffixes,ext,sep="")
	filename<-filenames[which(file.exists(filenames)==FALSE)[1]]
	return(filename)
}

#use whole X11 terminal window

resize <- function(){
	if(.Platform$GUI=="X11"){
		.adjustWidth <- function(...){
			options(width=Sys.getenv("COLUMNS"))
			TRUE
		}
		.adjustWidthCallBack <- addTaskCallback(.adjustWidth)
	}
}


write.mat <-
function( mat, ... ){
	write.table(mat,sep="\t",quote=FALSE,col.names=FALSE, ... )
}

write.tsv <-
function( tsv, colnames=FALSE, rownames=FALSE, ... ){
	write.table(tsv,sep="\t",quote=FALSE,col.names=colnames,row.names=rownames, ... )
}

'%ni%' <- Negate('%in%')

lsl<-function(){system("ls -l")}
lsltr<-function(){system("ls -ltr")}
lslSr<-function(){system("ls -lSr")}
lslt<-function(){system("ls -lt")}
lslS<-function(){system("ls -lS")}

rerage<-function(){ 
	   
	system("buildrage")
	detach("package:rage",unload=T)
	library(rage)
}

shead<- function(filename, n=10){
	s <- system(paste("head -n",n,filename),intern=FALSE)
	return(s)
}