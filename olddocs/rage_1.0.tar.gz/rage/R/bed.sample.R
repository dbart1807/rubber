bed.sample <-
function( bed , count ){
	library(tools)
	totallines<-filelines(bed)
	if(count > totallines ){stop("sample quantity is greater than available lines")}
	outname<-paste(basename(removeext(bed)),"_random",count,".",file_ext(bed),sep="")
	system(paste("randomLines",beds[i],numfrags,newname))
}
