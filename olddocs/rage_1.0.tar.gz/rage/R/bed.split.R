bed.split <-
function( bed,regionsize,windowsize,covbedname ){
	numwindows<-(regionsize/windowsize)

	bedname<-basename(removeext(bed))
	curbed<-read.tsv(bed)

	bedrows<-nrow(curbed)
	bedcols<-ncol(curbed)
	#check parameters
	if(ceiling(numwindows)!=floor(numwindows)){stop("regionsize is not a multiple of windowsize")}
	if(ceiling(regionsize)!=floor(regionsize)){stop("regionsize must be an even number")}

	#make covbed
	flanks<- (  0:(numwindows-1)  ) * windowsize
	winstarts<-as.numeric( unlist( lapply( curbed[,2] , function(x) x + flanks ) ) )
	covbed<-data.frame(
		"V1"=rep(curbed[,1],each=numwindows),
		"V2"=format(winstarts,scientific=F,trim=T),
		"V3"=format(winstarts+windowsize,scientific=F,trim=T),
		"V4"=1:(bedrows*numwindows)
	)
	write.tsv(covbed,file=covbedname)
	system(paste("sort -k1,1 -k2,2n -k3,3n",covbedname,"-o",covbedname))
	covbedorder<-as.numeric(readLines(pipe(paste("cut -f 4",covbedname))))
	return(covbedorder)
}
