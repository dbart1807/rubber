bam.2.bed <-
function( bamfile , paired = FALSE ){
	bamname<-basename(removeext(bamfile))
	outname<-paste(bamname,".bed",sep="")
	system(paste("bedtools bamtobed","-i",bamfile,if(paired){"-bedpe | cut -f 1,2,6"},"| sort -T . -k1,1 -k2,2n > ",outname))
	return(outname)
}
