bam.cat <- function( bamfiles , outname ){
	exitstatus <- system(paste("samtools cat -o" , outname , paste(bamfiles, collapse=" ") ) )
	if(exitstatus==0){cat("done\n")} else{cat("failed\n")}
	return(outname)
}