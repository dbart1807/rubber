bed.sort <-
function( bedfile ){
	library(tools)
	ext<-file_ext(bedfile)
	system(paste("sort -k1,1 -k2,2n",bedfile,"-o",bedfile))
	return(bedfile)
}
