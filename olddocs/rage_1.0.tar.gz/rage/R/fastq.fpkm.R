fastq.fpkm <-
function( read1file, read2file="", genome="hg19", librarytype="fr-firststrand", speed="--b2-very-fast", outdir=basename(removeext(read1file)) , cores="max"){
	library(parallel)
	if(cores=="max"){cores<-detectCores()-1}
	read1name<-basename(removeext(read1file))
	indexfile<-getbt2index(genome)
	tindexfile<-gettindex(genome)
	gtf<-getgtf(genome)
	cat(read1name,": aligning to genome\n")
	cat(paste("tophat -T -o ",outdir," --library-type ",librarytype," -p ",cores," --transcriptome-index=",tindexfile," ",indexfile," ",read1file," ",read2file,sep=""))
	cat("\n\n")
	system(paste("tophat -T -o ",outdir," --library-type ",librarytype," -p ",cores," --transcriptome-index=",tindexfile," ",indexfile," ",read1file," ",read2file,sep=""))
	bamfile<-(paste(outdir,"/accepted_hits.bam",sep=""))
	cat(paste("cufflinks","-G",gtf,"--library-type",librarytype,"-p",cores,"-o",outdir,bamfile))
	cat("\n\n")
	system(paste("cufflinks","-G",gtf,"--library-type",librarytype,"-p",cores,"-o",outdir,bamfile))
	return(paste(outdir,"/genes.fpkm_tracking",sep=""))
}
