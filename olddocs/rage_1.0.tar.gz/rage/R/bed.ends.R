bed.ends <-
function( bedfile, fiveprime=TRUE, threeprime=TRUE ){
	if(length(bedfile) > 1){stop("this function can only take 1 file. use lapply.")}
	outname<-paste0(basename(removeext(bedfile)),"_ends.bed")
	system(paste("awk '{",if(fiveprime){"print $1,$2,$2+1"},if(fiveprime & threeprime){";"},if(threeprime){"print $1,$3,$3+1}'"}," OFS='\t'",bedfile,"| sort --parallel=4 -T . -S 10G -k1,1 -k2,2n >",outname))
	return(outname)
}
