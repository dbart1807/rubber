bg.2.bw <-
function( datafiles, genomefile ){
	outnames <- paste0(basename(removeext(datafiles)),".bw")
	for(l in 1:length(datafiles)){
		system(paste("bedGraphToBigWig", datafiles[l], genomefile, outnames[l] ) )
	}
	return(outnames)
}
