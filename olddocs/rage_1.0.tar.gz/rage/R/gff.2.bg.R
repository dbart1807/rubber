gff.2.bg <-
function( gff, extendbp=NULL ){
	system(paste("sort -k1,1 -k4,4n",gff,"-o",gff))
	gffname<-basename(removeext(gff))
	outname<-paste0(gffname,".bg")
	gff<-read.delim(pipe(paste("cut -f 1,4,5,6",gff)),stringsAsFactors=FALSE,header=FALSE)
	if( is.null(extendbp)==FALSE ){
		cat(gffname,": extending 5' ends by",extendbp,"bp\n")
		gff$V3<-gff$V2+extendbp
	}
	write.tsv(gff,file=outname)
	return(outname)
}
