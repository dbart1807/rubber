rage.hist <-
function( scorelist , vlines=0, hlines=0, cdf = FALSE , dens=TRUE , drawlegend = TRUE , legendpos="topright" , fraction = FALSE , brks = 50 , reverse = FALSE , xlims=NULL, plotcolors=rainbow(length(scorelist)), legendnames=names(scorelist) ) {
	
	library(parallel)
	numbeds<-length(scorelist)
	if(is.null(names(scorelist))){ names(scorelist) <- 1:length(scorelist) }
	
	numfrags<-unlist(lapply(scorelist, length))
	
	if(is.null(xlims)){
		xlims=c(min(unlist(scorelist)), max(unlist(scorelist)))
	}
	
	if(cdf==FALSE){
		if(dens){
			densitylist<-mclapply( scorelist, density, from=xlims[1], to=xlims[2], mc.cores=detectCores() )
			xl<-lapply( lapply( densitylist, "[" , 1), unlist )
			yl<-lapply( lapply( densitylist, "[" , 2), unlist )
			ymax<-max(unlist(yl))
			ylabel = "density"

		} else{
			scorelist <- mclapply( 1:numbeds, function(x) scorelist[[x]][which(scorelist[[x]] >= xlims[1] & scorelist[[x]] <= xlims[2] )] )
			densitylist<-mclapply( scorelist, hist, plot=FALSE, breaks=brks )
			xl<-lapply( lapply( densitylist, "[" , 4), unlist )
			yl<-lapply( lapply( densitylist, "[" , 2), unlist )
			ylabel = "count"
			if(fraction){
				yl <- lapply( 1:numbeds, function(x) yl[[x]]/length(scorelist[[x]] ) )
				ylabel="proportion"
			}
			ymax<-max(unlist(yl))
			
		}
		
	} else{
		xl <- lapply( scorelist, sort )
		yl <- lapply( 1:numbeds, function(x) length(xl[[x]]) - ( 1:length(xl[[x]]) ) )
		ylabel = "cumulative sum"
		if(reverse){
			yl <- lapply( 1:numbeds, function(x) length(xl[[x]]) - yl[[x]] )
		}
		if(fraction){
			yl <- lapply( 1:numbeds, function(x) yl[[x]]/length(xl[[x]]) )
			ylabel = "cumulative proportion"
		}
		
		ymax<-max(unlist(yl))
		
	}	

	
	plot(0,type="n",ylim=c(0,ymax), xlim=xlims, xlab="value", ylab=ylabel)
	
	for(i in 1:numbeds){
		lines(xl[[i]],yl[[i]],col=plotcolors[i],lwd=2)
	}

	abline(v=vlines, col="grey80")
	abline(h=hlines, col="grey80")
	
	if(drawlegend){
		legend(legendpos,legend=paste(legendnames,", n=",numfrags), col=plotcolors, lwd=3)	
	}
	
}