bg.qnorm2 <-
function( bgs, numsamples=10, normalizeto=NULL, cores ="max" ){
	
	library(tools)
	library(parallel)
	
	numbgs<-length(bgs)
	
	if(cores=="max"){cores=detectCores()-1}
	if(cores > numbgs){cores=numbgs}
	
	
	bgnames<-basename(removeext(bgs))
	exts<-file_ext(bgs)
	
	cat("reading\n")
	bglist<-read.bgs(bgs)
	numscores<-nrow(bglist)
	bg<-read.tsv(bgs[1])
	
	cat("combining\n")
	if(is.null(normalizeto)){
		scores <- as.vector(unlist(bglist))
	} else{
		scores <- rep(as.vector(unlist(bglist[[normalizeto]])),10)
	}

	cat("sampling\n")
	samples <- sort(rowMeans(as.data.frame(mclapply(1:numsamples, function(x) sort(sample(scores,numscores)),mc.cores=cores))))
	
	cat("normalizing\n")	
	bglist<-mclapply( 1:numbgs,function(x) {
			bglist[[x]][order(bglist[[x]])]<-samples
			bglist[[x]]
	}, mc.cores=cores )

	cat("saving\n")
	outnames<-paste(bgnames,"_qnorm.",exts, sep="") 
	mclapply(1:numbgs, function(x) write.tsv(cbind(bg[,1:3],bglist[[x]],file=outnames[x]) ,mc.cores=cores ) )
	return(outnames)
}
