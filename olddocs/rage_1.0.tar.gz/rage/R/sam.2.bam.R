sam.2.bam <-
function( samfiles, q=10 ){
	outnames <- paste0(removeext(samfiles),".bam")
	for(i in 1:length(samfiles)){
		system(paste("samtools view -q",q,"-Sb ",samfiles,">",outnames[i] ) )
	}
	return(outnames)
}
