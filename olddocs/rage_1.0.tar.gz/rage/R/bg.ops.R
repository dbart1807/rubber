bg.ops <-
function( bglist1 , operation , bglist2=NULL , outnames = NULL , pattern=NULL , replacement=NULL ){

	library(tools)

	# check that file has only 4 columns
	# check that file line counts are equal

	numbgs <- length(bglist1)
	# argument check
	if( is.null(outnames)==FALSE & is.null(pattern)==FALSE & is.null(replacement)==FALSE & numbgs!=1 & is.null(bglist2)==FALSE) {
		stop("must use pattern/replacement OR outnames, not both")
	}

	if( length ( operation ) != 1){stop("can only perform 1 operation")}

	bglist1ext<-file_ext(bglist1)
	bglist2ext<-file_ext(bglist2)

	if(is.null(bglist2)==FALSE & length(bglist2) == 1 & numbgs > 1){
		bglist2 <- rep(bglist2,numbgs)
	}

	if( is.null(outnames) ){
		#cat("creating output names\n")
		outnames<-gsub(pattern,replacement,basename(bglist1))
		
		#nametab<-data.frame("MATRIX1"=basename(bglist1),"MATRIX2"=basename(bglist2),"OUTPUT"=outnames,stringsAsFactors=FALSE)
		#print(nametab)
		if(length(which(bglist1 %in% outnames)==TRUE)>0){stop("AT LEAST ONE OUTPUT FILE WILL REPLACE AN INPUT FILE")}
		if(is.null(bglist2)==FALSE){
			if(length(which(bglist2 %in% outnames)==TRUE)>0) {stop("AT LEAST ONE OUTPUT FILE WILL REPLACE AN INPUT FILE")}
		}
	}
	
	if( is.null(bglist2)==FALSE & length(outnames) != numbgs){ stop("outnames must be of same length as bglist1")}

	if( is.null(bglist2) ){
		if(operation %ni% c("mean","sd","log2","log10","antilog2","antilog10","inverse","mediancenter","meancenter")) { stop("operations that can be performed on a single matrix include log2, log10, antilog2, antilog10, and inverse")}
		if(is.null(outnames)){outnames <- paste0 (basename(removeext(bglist1)) , "_",operation,".",bglist1ext)}
		scorecols<-paste(paste0("$",4*(1:4)),collapse="+")
		#if(sum(grepl(0,mat))>0){cat("WARNING: MATRIX CONTAINS ZEROES THAT WILL BE INFINITE IF CALCULATING A LOGARITHMIC\n")}
		if(operation == "mean"){
			mn <- system(paste0("paste ",paste(bglist1)," | awk '{print $1,$2,$3,",scorecols,"/",numbgs,"}' OFS='\t' > ",outnames[1]))
		} else if(operation == "sd"){
			system(paste0("paste ",paste(bglist1)," | awk 'BEGIN {n=",numbgs,"} { s=0 ; m=(",scorecols,")/",numbgs,"; for (i=1;i<=",numbgs,";i++){ s+=($(i*4)-m)^2 } print $1,$2,$3,sqrt(s/(n-1))}' OFS='\t' > ",outnames[1]))
		} else{
			if(operation=="log2"){
				op <- "log($4)/log(2)"
			}
			if(operation=="log10"){
				op <- "log($4)/log(10)"
			}
			if(operation=="antilog2"){
				op <- "2^$4"
			}
			if(operation=="antilog10"){
				op <- "10^$4"
			}
			if(operation=="inverse"){
				op <- "1/$4"
			}
			if(operation=="mediancenter"){
				med <- as.numeric(system(paste("cut -f 4",bglist1[1],"| sort -k1,1n | awk 'BEGIN{i=0} {a[i]=$1 ; i++} END{print a[int(NR/2)]}'"),intern=TRUE))
				op<- paste0("$4-",med)
			}
			if(operation=="meancenter"){
				avg <- as.numeric(system(paste("awk '{a+=$4} END {print a/NR}'",bglist1[1]),intern=TRUE))
				op <- paste0("$4-",avg)
			}
			system(paste0("awk '{print $1,$2,$3,",op,"}' OFS='\t' ",bglist1[1]," > ",outnames[1]))
		}
	}

	if( is.null(bglist2)==FALSE & length(bglist2) == numbgs ){

		if(operation %ni% c("log2ratio","ratio","difference","mean")) { stop("operations that can be performed on pairs of files include log2ratio, ratio, difference, and mean")}
		if(operation=="log2ratio"){ op <- "log($4/$8)/log(2)" }
		if(operation=="ratio"){ op <- "$4/$8" }
		if(operation=="difference"){ op <- "$4-$8" }
		if(operation=="mean"){ op <- "($4+$8)/2" }

		for(i in 1:numbgs){
			system(paste0("paste ",bglist1[i]," ",bglist2[i]," | awk '{print $1,$2,$3,",op,"}' OFS='\t' > ",outnames[i]))
		}
	}

	return(outnames)
}
