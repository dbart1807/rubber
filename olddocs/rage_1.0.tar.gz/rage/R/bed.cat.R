bed.cat <- function (beds , outname , sort=TRUE , buffersize="10G" , cores=8 ){
	print(paste("cat",paste(beds,collapse=" ") , if(sort){ paste("| sort -T . -S",buffersize,"--parallel",cores,"-k1,1 -k2,2n") }, ">" , outname ))
	system(paste("cat",paste(beds,collapse=" ") , if(sort){ paste("| sort -T . -S",buffersize,"--parallel",cores,"-k1,1 -k2,2n") }, ">" , outname ))
	return(outname)
}