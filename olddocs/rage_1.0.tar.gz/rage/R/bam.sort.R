bam.sort <-
function( bamfile, memory=0.5*totalmem(), sortby="position" ){
	bamname<-basename(removeext(bamfile))
	if(sortby=="name"){extraargs="-n";suffix="_nsort"}
	if(sortby=="position"){extraargs="";suffix="_psort"}
	outname<-paste0(bamname,suffix)
	
	system(paste("samtools sort",extraargs,bamfile,outname))
	return(outname)
}
