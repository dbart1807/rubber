bg.cors <-
function( bgfiles, outpdfname, bgnames=basename(removeext(bgfiles)), cores="max"  ){
	library(parallel)
	library(gplots)
	if(cores=="max"){cores=detectCores()-1}
	bgnames<-basename(removeext(bgfiles))
	numbgs<-length(bgfiles)
	
	colramp <- colorRampPalette(c("red","black","green"), space = "rgb")
	brks=seq(-1,1,by=2/100)
	hcolors<-colramp(100)
	
	#make list of matrices
	cat("reading in bedgraphs\n")
	bglist<-mclapply(bgfiles,read.tsv,mc.cores=cores)
	
	#make pairwise matrix correlations
	cat("calculating global correlations\n")
	pairs<-expand.grid(1:numbgs,1:numbgs)
	bgcors<-as.numeric(unlist(mclapply(1:nrow(pairs),function(x) cor(bglist[[pairs[x,1]]][,4] , bglist[[pairs[x,2]]][,4] , use="complete.obs" ),mc.cores=cores)))
	cormat<-matrix(bgcors,nrow=numbgs,ncol=numbgs)
	row.names(cormat)<-bgnames
	colnames(cormat)<-bgnames
	#for(i in 1:nrow(pairs)){
	#	cormat[pairs[i,1],pairs[i,2]]<-matcors[i]
	#}
	#globaltablename<-paste(matnames[1],"_globalcors.tsv",sep="")
	#cat("saving global correlation table to",globaltablename,"\n")
	#write.table(cormat,file=globaltablename,sep="\t",row.names=TRUE,col.names=TRUE,quote=FALSE)
	
	#plot pairwise global correlations as a heatmap
	cat("saving bg cross-correlation heatmap to",outpdfname,"\n")
	pdf(file=outpdfname)
	heatmap.2(cormat,Rowv=NA,Colv=NA,dendrogram="none",trace="none",col=hcolors,breaks=brks,main="Global cross-correlations")
	dev.off()
}
