bed.clip <-
function( datafiles,genomefile){
	library(tools)
	for(l in 1:length(datafiles)){
		cat(basename(datafiles[l]),": clipping bed\n")
		ext<-file_ext(datafiles[l])
		outname<-paste(basename(removeext(datafiles[l])),".",ext,sep="")
		system(command=paste("bedClip", datafiles[l], genomefile , outname))
		return(outname)
	}
}
