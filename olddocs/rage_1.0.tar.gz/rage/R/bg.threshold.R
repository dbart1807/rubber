bg.threshold <-
function( bgfile, segmentnames=c("HS","HR"), segmergedist=75,cutoff=1, positive=TRUE, negative=FALSE){
	
	bgname<-basename(removeext(bgfile))
	
	cat("finding HS and HR regions\n")
	if(positive==TRUE){
		hsname<-paste0(bgname,"_Min",cutoff,".bg")
		hs<-bg.selectscores(bgfile,range=c(cutoff,Inf))
		hs<-bed.merge(hs,flank=segmergedist)
		hs<-bg.map(bgfile,hs,operation="max",outname=hsname)
	}
	if(negative==TRUE){
		hrname<-paste0(bgname,"_Max",cutoff,".bg")
		hr<-bg.selectscores(bgfile,range=c(-Inf,-1*cutoff))
		hr<-bed.merge(hr,flank=segmergedist)
		hr<-bg.map(bgfile,hr,operation="min",outname=hrname)
	}
	outnames<-c(if(positive==TRUE){hsname},if(negative==TRUE){hrname})
	return(outnames)
}
