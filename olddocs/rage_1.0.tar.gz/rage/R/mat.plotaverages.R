mat.plotaverages <-
function( matrixlist,main="",centername="TSS",plottype="l",ylims=c("auto","auto"),X=TRUE,prefix="unnamed",plotcolors=rainbow(length(matrixlist)),legendnames=basename(removeext(matrixlist))){
	library(tools)
	library(parallel)
	cores=detectCores()-1
	nummats<-length(matrixlist)
	matlist<-mclapply(matrixlist,read.mat,mc.cores=cores)
	mataverages<-mclapply(matlist,colMeans,na.rm=TRUE,mc.cores=cores)
	ymax<-max(unlist(mataverages),na.rm=TRUE)
	ymin<-min(unlist(mataverages),na.rm=TRUE)
	if(ylims[1]=="auto"){ylims[1]=ymin}
	if(ylims[2]=="auto"){ylims[2]=ymax}
	ylims<-as.numeric(ylims)
	windowsizes<-as.numeric(gsub("mat","",file_ext(matrixlist)))
	matcols<-unlist(lapply(matlist,ncol))
	xs<-lapply(1:nummats,function(x) ((1:matcols[x])-(matcols[x]/2))*windowsizes[x])
	if(X==FALSE){pdf(file=paste(prefix,"_averages.pdf",sep=""))}
	plot(
        	0,
		type="n",
    		xlim=c(min(xs[[1]]),max(xs[[1]])),
		ylim=ylims,
    		xlab=paste("Distance from",centername,"(bp)"),
    		ylab="Average score",
    		cex=0.5,
    		main=main
		#cex.lab=1.5,
    		#cex.axis=1.5,
    		#cex.main=1.5,
    		#cex.sub=1.5
    	)
	for(k in 1:nummats){
		lines(
		      xs[[k]],
		      mataverages[[k]],
		      col=plotcolors[k],
		      lwd=1,
		      type=plottype
		)
    	}
	legend("topleft",legend=legendnames, col=plotcolors, lwd=3)
	if(X==FALSE){dev.off()}
}
