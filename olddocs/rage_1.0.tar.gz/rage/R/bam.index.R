bam.index <-
function( bamfile ){
	bamname<-basename(removeext(bamfile))
	cat(bamname,": indexing\n")
	system(paste("samtools index",bamfile))
}
