bam.count <-
function ( bamfile , q = 10 ){
	return( as.numeric ( system( paste( "samtools view -c -q" , q , bamfile ) , intern=TRUE ) ) )
}
