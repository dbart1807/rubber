bed.coverage <-
function( bedfile , windowfile , windowsize=25 , stepsize=windowsize , scalar="rpm" , abam=FALSE ){

	#check if only 1 file
	if(length(bedfile) > 1){stop("bed.windowcov can only take 1 bedGraph file")}
	if(length(windowfile) > 1){stop("bed.windowcov can only take 1 window file")}
	if(abam){a="-abam"} else{a="-a"}
	#get base name
	bedname<-basename(removeext(bedfile))
	winname<-basename(removeext(windowfile))
	outname<-paste0(basename(removeext(bedfile)),"_",winname,".bg")
	overlapsize<-(windowsize-stepsize)/2
	lsub=floor(overlapsize)

	#calculate scaling factor
	if(scalar=="rpm"){
		scalar=1000000/filelines(bedfile)
	}

	#calculate coverage over windowfile
	print(paste(
		"bedtools coverage -counts",a,bedfile,"-b",windowfile,"| awk '{print $1,$2",if(stepsize<windowsize){paste("+",lsub)},",",if(stepsize<windowsize){paste("$2+",lsub,"+",stepsize)} else{"$3"},",$4*",scalar,"}' OFS='\\t' | sort -k1,1 -k2,2n >",outname
	))
	system(paste(
		"bedtools coverage -counts",a,bedfile,"-b",windowfile,"| awk '{print $1,$2",if(stepsize<windowsize){paste("+",lsub)},",",if(stepsize<windowsize){paste("$2+",lsub,"+",stepsize)} else{"$3"},",$4*",scalar,"}' OFS='\\t' | sort -k1,1 -k2,2n >",outname
	))

	return(outname)
}
