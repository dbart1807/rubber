hub.bed <-
function( trackfiles, bedcols, usescore = FALSE , descriptions = "" , port = 22 , group = NULL , ra = FALSE , color=TRUE, parentname=NULL, composite=FALSE, maxitems=1000, densecoverage=NULL, colorbystrand=NULL, tracknames=removeext(trackfiles), hubloc="dvera@epsilon.bio.fsu.edu:public_html/hubs/dlv/hg19",printtrack=F){
	library(tools)
	if(length(which(file_ext(trackfiles) %in% c("bed")) > 0)){stop("cannot create track from bed files, convert to bigBed")}
	print(data.frame("file"=trackfiles,"names"=tracknames))
	if(composite==TRUE & is.null(parentname)){stop("must specify parent name if composite=TRUE")}
	if(ra & is.null(group)){stop("must have a group if ra == TRUE")}
	#check if dense coverage is numeric and not logical
	if(composite){tracknames2 <- paste0(parentname,"_",tracknames)} else{tracknames2<-tracknames}
	if(composite & length(descriptions) >1){stop("can only have 1 description for composite track")}
	if(composite==FALSE & length(descriptions) != length(trackfiles)){stop("description length should be equal to track #")}
	if(composite){
		track<-c(
			"",
			"",
			paste("track",parentname),
			paste("shortLabel",parentname),
			paste("longLabel",parentname),
			paste("type bigBed",bedcols,"."),
			"compositeTrack on",
			"visibility hide",
			"allButtonPair on",
			"dragAndDrop on",
			if(usescore){paste("spectrum on")},
			if(ra){paste("group",group)},
			paste0("html html/",parentname),
			if(color){paste("itemRgb on")},
			if(is.null(colorbystrand)==FALSE){paste("colorByStrand",paste(col2rgb(colorbystrand[1]),collapse=","),paste(col2rgb(colorbystrand[2]),collapse=","),sep=" ")},
			if(is.null(densecoverage)==FALSE){paste("denseCoverage",densecoverage)},
			""
			)
	} else{
		track<-""
	}
	
	for(i in 1:length(trackfiles)){
		subtrack<-c(
			paste("track",tracknames2[i]),
			if(ra==FALSE){paste("bigDataUrl bbi/",trackfiles[i],sep="")},
			paste("shortLabel",tracknames[i]),
			paste("longLabel",tracknames[i]),
			paste("type bigBed",bedcols,"."),
			paste("maxItems",maxitems),
			"visilbility hide",
			if(composite==FALSE & usescore){paste("spectrum on")},
			if(composite==FALSE & ra){paste("group",group)},
			if(color){paste("itemRgb on")},
			if(is.null(colorbystrand)==FALSE){paste("colorByStrand",paste(col2rgb(colorbystrand[1]),collapse=","),paste(col2rgb(colorbystrand[2]),collapse=","),sep=" ")},
			if(is.null(densecoverage)==FALSE){paste("denseCoverage",densecoverage)},
			if(composite){paste("parent",parentname)},
			if(composite==FALSE){paste0("html html/",tracknames[i])},
			""
		)
		track<-append(track,subtrack)
	}
	
	if(ra){	targetfile="trackDb.ra" } else { targetfile="hubDb.txt" }
	trackfile<-data.frame("V1"=track,stringsAsFactors=FALSE)
	if(printtrack){cat(unlist(trackfile),sep="\n")} else{write.tsv(trackfile,file="tmphubdb.txt")}
	filelist<-paste(trackfiles,sep=" ",collapse=" ")
	print(filelist)
	login<-unlist(strsplit(hubloc,":"))[1]
	path<-unlist(strsplit(hubloc,":"))[2]
	genome<-basename(path)
	#cat(paste("scp ",hubloc,"/bbi/",sep=""))
	print(paste("scp -P ",port," ",filelist," ",hubloc,"/bbi/",sep=""))
	system(paste("scp -P ",port," ",filelist," ",hubloc,"/bbi/",sep=""))
	print(paste0("cat tmphubdb.txt | ssh -p ",port," ",login," 'cat >> ",path,"/",targetfile,"'"))
	system(paste0("cat tmphubdb.txt | ssh -p ",port," ",login," 'cat >> ",path,"/",targetfile,"'"))
	if(composite){
		print(paste0("ssh -p ",port," ",login," '",paste(paste0("echo \"",descriptions,"\" > ",path,"/html/",parentname,".html"),collapse=" && "),"'"))
		system(paste0("ssh -p ",port," ",login," '",paste(paste0("echo \"",descriptions,"\" > ",path,"/html/",parentname,".html"),collapse=" && "),"'"))
	} else{
		print(paste0("ssh ",login," '",paste(paste0("echo \"",descriptions,"\" > ",path,"/html/",basename(trackfiles)),collapse=" && "),"'"))
		system(paste0("ssh ",login," '",paste(paste0("echo \"",descriptions,"\" > ",path,"/html/",basename(trackfiles)),collapse=" && "),"'"))
	}
	if(ra){
		print(paste0("ssh -p ",port," ",login," '",paste(paste0("~/bin/x86_64/hgBbiDbLink ",genome," ",tracknames2," ",path,"/bbi/",basename(trackfiles)),collapse=" && "),"'"))
		system(paste0("ssh -p ",port," ",login," '",paste(paste0("~/bin/x86_64/hgBbiDbLink ",genome," ",tracknames2," ",path,"/bbi/",basename(trackfiles)),collapse=" && "),"'"))
		print(paste("ssh -p",port,login,"'~/bin/x86_64/hgTrackDb",path,genome,"trackDb","/gbdb/kent/src/hg/lib/trackDb.sql",path,"'"))
		system(paste("ssh -p",port,login,"'~/bin/x86_64/hgTrackDb",path,genome,"trackDb","/gbdb/kent/src/hg/lib/trackDb.sql",path,"'"))
	}
}
