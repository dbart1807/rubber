fastq.bt2 <-
function( read1files, indexfile , read2files=NULL,cores="max", mode="end-to-end",input="-q", q=10, makebam = TRUE , makebed = TRUE , all=FALSE , dovetail=TRUE , discordant=FALSE , mixed=FALSE , unaligned=FALSE ){
	
	library(parallel)
	if(cores=="max"){cores<-detectCores()-1}
	
	read1names<-basename(removeext(read1files))
	
	if(is.null(read2files)){
		paired=FALSE
		outnames<-paste(basename(removeext(read1files)),".sam",sep="")
	} else{
		paired=TRUE
		outnames<-paste(basename(removeext(read1files)),".sam",sep="")
	}
	
	for(i in 1:length(read1files)){
		cat(read1names[i],": aligning to genome\n")
		if(paired==TRUE){
			print(paste(
				"bowtie2",
				"-p",cores,
				if(dovetail){"--dovetail"},
				if(mixed==FALSE){"--no-mixed"},
				if(discordant==FALSE){"--no-discordant"},
				if(unaligned==FALSE){"--no-unal"},
				if(all){"-a"},
				input,
				"-x",indexfile,
				"-1",read1files[i],
				"-2",read2files[i],
				"-S",outnames[i]
			))
			system(paste(
				"bowtie2",
				"-p",cores,
				if(dovetail){"--dovetail"},
				if(mixed==FALSE){"--no-mixed"},
				if(discordant==FALSE){"--no-discordant"},
				if(unaligned==FALSE){"--no-unal"},
				if(all){"-a"},
				input,
				"-x",indexfile,
				"-1",read1files[i],
				"-2",read2files[i],
				"-S",outnames[i]
			))
		}
		else{
			system(paste(
				"bowtie2",
				"-p",cores,
				if(all){"-a"},
				input,
				"-x",indexfile,
				"-U",read1files[i],
				"-S",outnames[i]
			))
		}
	}
	
	if(cores > length(read1files)) { cores <- length(read1files) }
	if(makebam) { outnames<-unlist(mclapply(outnames,sam.2.bam,mc.cores=cores,q=q)) }
	if(makebed) { outnames<-unlist(mclapply(outnames,bam.2.bed,if(paired){paired=TRUE} else{paired=FALSE},mc.cores=cores))}

	return(outnames)
}
