bed.intersect <-
function( a, b, extraargs="-u"){
	library(gtools)
	bed1name<-basename(removeext(a))
	bed2name<-basename(removeext(b))
	ext<-file_ext(a)
	outname<-paste0(bed1name,"_x_",bed2name,".",ext)
	system(paste("bedtools intersect -a",a,"-b",b,extraargs,">",outname))
	return(outname)
}
