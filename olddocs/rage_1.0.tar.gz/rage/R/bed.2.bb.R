bed.2.bb <-
function( datafiles , genomefile ) {
	outnames<-paste0(basename(removeext(datafiles[l])),".bb")
	for(i in 1:length(datafiles)){
		system( paste( "bedToBigBed", datafiles[i], genomefile , outnames[i] ) )
	}
}
