bb.2.bed <-
function( datafiles ){
	outnames<-paste0(basename(removeext(datafiles)),".bed")
	for(i in 1:length(datafiles)){
		system(paste("bigBedToBed", datafiles[i], outnames[i]))
	}
	return(outnames)
}
