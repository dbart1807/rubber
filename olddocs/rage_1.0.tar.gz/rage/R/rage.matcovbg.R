rage.matcovbg <-
function( covbedfile, bgfile , filler){
	#as.numeric(readLines(pipe(paste("bedtools map -c 4 -o mean -null \"",filler,"\" -a ",covbedfile," -b ",bgfile," | sort -k1,1 -k2,2n -k3,3n | cut -f 5",sep=""))))
	as.numeric(readLines(pipe(paste("bedtools map -c 4 -o mean -null \"",filler,"\" -a ",covbedfile," -b ",bgfile," | sort -k4,4n | cut -f 5",sep=""))))
}
