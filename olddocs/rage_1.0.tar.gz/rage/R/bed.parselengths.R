bed.parselengths <-
function( bedfile , brks=c(0,70,140,200) , cores=1 ){

	library(parallel)
	library(tools)
	if(cores=="max"){cores=detectCores()-1}

	# make sure input is only 1 file
	if(length(bedfile) > 1){stop("bed.parselengths can only take 1 file")}

	# check breaks
	numbreaks<-length(brks)
	if(numbreaks==1){stop("need two or more breakpoints")}

	numfrags<-filelines(bedfile)
	ext<-file_ext(bedfile)
	fragname<-basename(removeext(bedfile))
	brknames<-formatC(brks,width=nchar(brks[numbreaks]),format="d",flag="0")
	brknames[which(is.infinite(brks))]<-"Inf"

	cat(fragname,": ",numfrags/1000000," million fragments\n",sep="")

	# parse fragments by length
	outnames<-unlist(mclapply(1:(numbreaks-1),function(i){
		cat(fragname,": ","processing fragments of length ",brks[i],"-",brks[i+1],"\n",sep="")
		subfragname<-paste0(fragname,"_",brknames[i],"-",brknames[i+1],".bed",sep="")
		if(brks[i+1]==Inf){
			print(paste("awk '$3-$2 >=",brks[i],"'",bedfile,">",subfragname))
			system(paste("awk '$3-$2 >=",brks[i],"'",bedfile,">",subfragname))
		} else{
			system(paste("awk '$3-$2 >=",brks[i],"&& $3-$2 <",brks[i+1],"'",bedfile,">",subfragname))
		}
		numsubfrags<-filelines(subfragname)
		cat(fragname,": ",numsubfrags,"/",numfrags," found (",100*numsubfrags/numfrags,"%)\n",sep="")
		return(subfragname)
	},mc.cores=cores))
	return(outnames)
}
