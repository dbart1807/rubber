bed.genomecov <-
function( intervalfile, genomefile , covmode="-bg" , scalar="rpm", bam=FALSE ){
	if(length(intervalfile) > 1){stop("bed.genomecov can only take 1 file")}
	if(scalar=="rpm" & bam == FALSE){cat(intervalfile,": counting fragments\n");scalar<-1000000/filelines(intervalfile)}
	if(scalar=="rpm" & bam == TRUE){cat(intervalfile,": counting fragments\n");scalar<-1000000/bam.count(intervalfile)}
	if(covmode=="-d"){pipes<-"| awk '{print $1,$2,$2+1,$3}' OFS='\t'"}
	if(covmode=="-dz"){pipes<-"| awk '{print $1,$2+1,$2+2,$3}' OFS='\t'"}
	if(covmode=="-bg"){pipes<-""}
	outname<-paste(basename(removeext(intervalfile)),".bg",sep="")
	cat(intervalfile,": calculating genome coverage\n")
	if(bam==TRUE){inputarg="-ibam"} else{inputarg="-i"}
	system(paste("bedtools genomecov",covmode,"-g",genomefile,"-scale",scalar,inputarg,intervalfile,pipes,">",outname))
	cat(intervalfile,": genome coverage complete\n")
	return(outname)
}
