bgzip <- function( filename, clobber=FALSE ){
	outname <- paste0(basename(removeext(filename)),".gz" )
	system(paste("bgzip -c", if(clobber){"-f"}, filename , ">", outname))
	return(outname)
}