bg.map <-
function( bgfile, bedfile, outname = NULL , operation="mean" , windowsize=25, stepsize=windowsize, filler=0 , printzero=TRUE ){
	
	if(is.null(outname)){ outname<-paste0(basename(removeext(bgfile)),"_",basename(removeext(bedfile)),".bg") }
	
	overlapsize<-(windowsize-stepsize)/2

	lsub=floor(overlapsize)

	system(paste(
		"bedtools map -c 4 -o",operation,
		"-null",filler,
		"-a",bedfile,
		"-b",bgfile,
		if(printzero==F){"| awk '$4!=0)'"},
		if( stepsize<windowsize ){ paste( "| awk '{print $1,$2","+",lsub,",$2+",lsub,"+",stepsize,",$4}' OFS='\t'" ) } ,
		">" , outname ))
	
	return(outname)
}
