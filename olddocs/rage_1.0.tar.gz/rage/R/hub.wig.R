hub.wig <-
function( trackfiles, hubloc , descriptions = "" , group = NULL , ra = FALSE , range=c(0,50), parentname=NULL, multiwig=FALSE, composite=FALSE, tracknames=basename(removeext(trackfiles)), plotcolors=rainbow(length(trackfiles)), altcolors=plotcolors , printtrack=F){
	if(composite==TRUE & is.null(parentname)){stop("must specify parent name if composite=TRUE")}
	if(composite==TRUE & multiwig==TRUE){stop("cannot be both composite and multiwig")}
	if(ra & is.null(group)){stop("must have a group if ra == TRUE")}
	print(data.frame("file"=trackfiles,"names"=tracknames,"color"=plotcolors))
	track=""
	if(multiwig | composite){
		track<-c(
			"",
			"",
			paste("track",parentname),
			paste("shortLabel",parentname),
			paste("longLabel",parentname),
			paste("type bigWig",range[1],range[2]),
			if(multiwig){ "container multiWig" } else{ "compositeTrack on" } ,
			"graphType points",
			"configurable on",
			"visilbility hide",
			"maxHeightPixels 200:50:32",
			if(composite){ "allButtonPair on" },
			if(multiwig){ "aggregate transparentOverlay" },
			if(multiwig){ "showSubtrackColorOnUi on" },
			if(composite){ "dragAndDrop on" },
			"autoScale on",
			"windowingFunction mean",
			"yLineOnOff on",
			"yLineMark 0",
			"smoothingWindow off",
			"alwaysZero on",
			if(ra){paste("group",group)},
			paste0("html html/",parentname),
			""
			)
	}

	for(i in 1:length(trackfiles)){
		c<-paste(col2rgb(plotcolors[i]),collapse=",")
		a<-paste(col2rgb(altcolors[i]),collapse=",")
		
		subtrack<-c(
			paste("track ",if(multiwig){paste(parentname,"-",sep="")},tracknames[i],sep=""),
			if(ra==FALSE){paste("bigDataUrl bbi/",basename(trackfiles[i]),sep="")},
			paste("shortLabel ",tracknames[i],sep=""),
			paste("longLabel ",tracknames[i],sep=""),
			paste("type bigWig ",range[1]," ",range[2],sep=""),
			paste("color ",c,sep=""),
			paste("altColor ",a,sep=""),
			if(multiwig | composite){paste("parent",parentname)},
			if(multiwig==F | composite==F){paste("group",group)},
			if(multiwig==F | composite==F){"graphType points"},
			if(multiwig==F | composite==F){"configurable on"},
			if(multiwig==F | composite==F){"visilbility hide"},
			if(multiwig==F | composite==F){"maxHeightPixels 200:50:32"},
			if(multiwig==F | composite==F){"autoScale on"},
			if(multiwig==F | composite==F){"windowingFunction mean"},
			if(multiwig==F | composite==F){"yLineOnOff on"},
			if(multiwig==F | composite==F){"yLineMark 0"},
			if(multiwig==F | composite==F){"smoothingWindow off"},
			if(multiwig==F | composite==F){"alwaysZero on"},
			if(multiwig==F | composite==F){paste0("html html/",tracknames[i])},
			""
		)
		track<-append(track,subtrack)
	}
	
	if(ra){	targetfile="trackDb.ra" } else { targetfile="hubDb.txt" }
	trackfile<-data.frame("V1"=track,stringsAsFactors=FALSE)
	if(printtrack){cat(unlist(trackfile),sep="\n")} else{write.tsv(trackfile,file="tmphubdb.txt")}
	filelist<-paste(trackfiles,sep=" ",collapse=" ")
	print(filelist)
	login<-unlist(strsplit(hubloc,":"))[1]
	path<-unlist(strsplit(hubloc,":"))[2]
	genome<-basename(path)
	#print(paste("scp ",hubloc,"/bbi/",sep=""))
	print(paste0("scp ",filelist," ",hubloc,"/bbi/"))
	system(paste0("scp ",filelist," ",hubloc,"/bbi/"))
	print(paste0("cat tmphubdb.txt | ssh ",login," 'cat >> ",path,"/",targetfile,"'"))
	system(paste0("cat tmphubdb.txt | ssh ",login," 'cat >> ",path,"/",targetfile,"'"))
	system(paste0("ssh ",login," '",paste(paste0("echo \"",descriptions," > ",path,"/",basename(trackfiles)),collapse=" && "),"'"))
	if(ra){
		print(paste0("ssh ",login," '",paste(paste0("hgBbiDbLink ",genome," ",tracknames," ",path,"/bbi/",basename(trackfiles)),collapse=" && "),"'"))
		system(paste0("ssh ",login," '",paste(paste0("hgBbiDbLink ",genome," ",tracknames," ",path,"/bbi/",basename(trackfiles)),collapse=" && "),"'"))
		print(paste("ssh",login,"'hgTrackDb",genome,path,"/gbdb/kent/src/hg/lib/trackDb.sql",path))
		system(paste("ssh",login,"'hgTrackDb",genome,path,"/gbdb/kent/src/hg/lib/trackDb.sql",path))
	}
}
