mat.make <-
function( scorefiles , features , featurenames = NULL , regionsize=2000 , windowsize=10, strand=FALSE , featurecenter=TRUE , start=2 , stop=3 , prunefeaturesto=NULL , narrowpeak=FALSE , maskbed=NULL , bgfiller=0 , prunescores=FALSE , rpm=TRUE , closest=NULL , cores="max" , meta=FALSE , metaflank=1000 , suffix=NULL , scoremat=TRUE , fragmats=FALSE ){

        # TO DO
        # #######
        # add bed info to mat rownames
        # move tmp files to a tmp directory

  options(scipen=9999999999)
  library(tools)

  library(parallel)
  numscores <- length(scorefiles)
  numfeats <- length(features)
  if(is.null(featurenames)){
  	featurenames<-basename(removeext(features))
  } else{
  	if(length(featurenames) != numfeats ){stop("length of feature names should equal length of feature files")}
  }


	if(cores=="max"){cores=detectCores()-1}
	cores2<-floor(cores/numscores)
	if(cores2<1){cores2=1}
	if(cores2>numfeats){cores2 <- numfeats }

	numwindows<-regionsize/windowsize
	numfeats<-length(features)
	numscores<-length(scorefiles)

	#check parameters
	if(ceiling(numwindows)!=floor(numwindows)){stop("regionsize is not a multiple of windowsize")}
	if(ceiling(regionsize)!=floor(regionsize)){stop("regionsize must be an even number")}

	#make directory for saving files
	
	dnames<-paste0(featurenames,"_mat",windowsize)
	scorenames <- basename(removeext(scorefiles))
	snames<-lapply(1:numfeats, function(x) paste0(dnames[x],"/",scorenames,"_",featurenames[x],suffix,".mat",windowsize))
	names(snames) <- dnames

	#process features
	#for(i in 1:numfeats){
	#mclapply(1:numfeats,function(i){
	lapply(1:numfeats,function(i){

    	featfile<-features[i]
		featname<-featurenames[i]
		dname <- dnames[i]
		system(paste("mkdir -p",dname))

		if(is.null(closest) == FALSE){
			featfile<-bed.closest(featfile,closest,strand=strand)
		}

		#recenter narrowpeaks
		if(file_ext(featfile) %in% c("narrowPeak","narrowpeak","np") == TRUE & featurecenter==TRUE & narrowpeak==TRUE){
			cat("narrowPeak file detected\n")

			#check if peak location is in narrowPeak file and recenter features if OK
			headlines<-as.numeric(readLines(pipe(paste("head",featfile,"| awk '{print $10}'"))))
			if(length(which(headlines %in% (-1)>0))){
				cat("bad peak coordinate detected in narrowPeak file, treating as bed\n")
			} else{
				cat("peak coordinates detected in narrowPeak file, recentering bed features\n")
				outname<-paste(featname,"_recentered.np",sep="")
				system(paste("awk '{$2=$2+$10;$3=$2+$10+1;print}' OFS='\t' ",featfile," | sort -k1,1 -k2,2n > ",outname,sep=""))
				featfile<-outname
			}
		}

		#create window bed for pruning
		if(meta==FALSE){
			cat("calculating matrix boundaries\n")
			featfile<-bed.recenter(featfile,regionsize,center=featurecenter,strand=strand,start=start,stop=stop )
		}

		#prune features to specified file
		if(is.null(prunefeaturesto) == FALSE){
			cat("pruning features\n")
			featfile<-bed.intersect(featfile,prunefeaturesto)
		}

		#copy processed features to output directory for later use
		system(paste("cp ",featfile," ",dname,"/",sep=""))

		#read in bed and get dimensions
		cat("reading in bed and getting info\n")
		curbed<-read.tsv(featfile)

		#discard regions beyond chromosome boundaries
    	if(meta){
			curbed<-curbed[which(curbed[,2]>metaflank+1),]
			write.tsv(curbed,file=featfile)
		}

		bedcols<-ncol(curbed)
		bedrows<-nrow(curbed)

		# FEATURES SHOULD NOT BE MODIFIED AFTER THIS POINT #

		#find minus-stranded features
		if(bedcols < 6 & strand==TRUE){strand=FALSE;cat("WARNING: RUNNING WITH strand=FALSE BECAUSE NO STRAND COLUMN EXISTS\n")}
		if(strand){negrows<-which(curbed[,6]=="-")}

		#make windows to calculate scores for matrix
		cat("calculating coordinates for matrix windows\n")
		if(meta){
		      covbedname <- paste0(basename(removeext(featfile)),".covbed")
		      covbedorder<-bed.split.meta(featfile,regionsize,windowsize, metaflank, covbedname , start=start, stop=stop )
		      numwindows<-(metaflank*2+regionsize)/windowsize
		} else{
		      covbedname <- paste0(basename(removeext(featfile)),".covbed")
		      covbedorder <- bed.split( featfile , regionsize , windowsize , covbedname )
		}

		#make matrix of regions to (not) mask with NAs
		if(is.null(maskbed) == FALSE){

     	 cat("finding masking regions\n")
			#maskmat<-t(matrix(rage.matcovbed(covbedname,maskbed)[order(covbedorder)],nrow=numwindows))
    	  maskmat<-t(matrix(rage.matcovbed(covbedname,maskbed),nrow=numwindows))

    	  if(strand){
				maskmat[negrows,1:numwindows]<-maskmat[negrows,numwindows:1]
			}

		}

		#assign row names to matrix
		cat("naming features\n")
		if(bedcols<4){
			geneids<-1:bedrows
		} else{
    	  geneids<-curbed[,4]
		}
		if(length(unique(geneids)) != bedrows){
			geneids<-paste(geneids,1:bedrows,sep="-")
		}
		if(bedcols>12){
			symbs<-curbed[,13]
		} else{
			symbs<-geneids
		}
		matrownames <- paste(geneids,curbed[,1],symbs,sep=";")




		#process each score file
		scores<-scorefiles
    	outs<-mclapply(1:length(scores), function(j) {

      	scorefile<-scores[j]
			scorename<-scorenames[j]

			#DOWNLOAD, EXTRACT, AND/OR FORMAT CONVERSION
			if(grepl("tp://",scorefile)){
				cat(scorename,": URL detected, attempting to download file to current directory\n")
				download.file(scorefile,basename(scorefile))
				scorefile<-basename(scorefile)
			}
			if(file_ext(scorefile) == "gz"){
				cat(scorename,": extracting with gunzip to current directory\n")
				system(paste("gunzip -c",scorefile,">",scorename ) )
				scorefile<-paste(basename(removeext(scorefile)),sep="")
				scorename<-basename(removeext(scorefile))
			}
			if(file_ext(scorefile) %in% c("wig","Wig") == TRUE){
				cat(scorename,": converting wig to bigWig\n")
				wig.2.bw(scorefile)
				scorefile<-paste(scorename,".bw",sep="")
			}
			if(file_ext(scorefile) %in% c("bb","bigbed","bigBed") == TRUE){
				cat(scorename,": converting bigBed to bed\n")
				bb.2.bed(scorefile)
				scorefile<-paste(scorename,".bed",sep="")
			}
			if(file_ext(scorefile) %in% c("bw","bigwig","bigWig") == TRUE){
				cat(scorename,": converting bigWig to bedGraph\n")
				bw.2.bg(scorefile)
				scorefile<-paste(scorename,".bg",sep="")
			}
			if(file_ext(scorefile) %in% c("cbed","bed","cfbg","broadPeak","broadpeak","narrowPeak","narrowpeak") ==TRUE){
				scoretype="bed"
			}
			if(file_ext(scorefile) %in% c("bg","bedgraph","bedGraph") ==TRUE){
				scoretype="bedgraph"
			}

			scorename<-basename(removeext(scorefile))

			cat(scorename,": counting scores\n")
			numfrags<-filelines(scorefile)
			cat(scorename,":",numfrags,"fragments\n")

			#PRUNE READS/SCORES TO REGIONS AROUND FEATURES
			if(prunescores){
				cat(scorename,": pruning scores to regions of interest\n")
				scorefile<-bed.intersect(scorefile,featfile)
				cat(scorename,": counting pruned scores\n")
				prunedscorecount<-filelines(scorefile)
				cat(scorename,":",prunedscorecount,"scores after pruning\n")
			}

			if(scoremat){
				#get coverage/average
				if(scoretype=="bed"){
					cat(scorename,": finding coverage of",scorename,"on",featname,"\n")
					curmat<-t(matrix(rage.matcovbed(covbedname,scorefile),nrow=numwindows))
				}
				if(scoretype=="bedgraph"){
					cat(scorename,": mapping scores in",scorename,"to",featname,"\n")
					curmat<-t(matrix(rage.matcovbg(covbedname,scorefile,bgfiller),nrow=numwindows))
		        }

				#flip rows of negative-stranded features
				if(strand){
					curmat[negrows,1:numwindows]<-curmat[negrows,numwindows:1]
				}

				#add row names to matrix
        		row.names(curmat)<-matrownames

		        #normalize by total fragments
				if(rpm & scoretype=="bed"){
					cat(scorename,": normalizing data\n")
					scalar<-1000000/numfrags
					curmat<-curmat*scalar
				}

				#mask uncovered regions with NA
				if(is.null(maskbed) == FALSE){
					cat(scorename,": masking data\n")
					curmat[maskmat==0]<-NA
				}

				#save matrix
				#outfilename<-paste(scorename,"_",featname,suffix,".mat",windowsize,sep="")
				write.mat(curmat,file=snames[[i]][j])
				cat(scorename,": matrix saved to",snames[[i]][j],"\n")
				
			}

			#make fragmats
			if(fragmats & scoretype == "bed"){
				
				cfbg<-cfbg.make(scorefile)
				
				cat(scorename,": creating fragmat\n")

				fmat<-readLines(pipe(paste("bedtools map -c 4 -o collapse -null \"NA\" -a ",covbedname," -b ",cfbg," | sort -k4,4n | cut -f 5",sep="")))
				fmat<-t(matrix(fmat,nrow=numwindows))

				if(strand==TRUE){
					cat("adjusting for strand\n")
					fmat[negrows,1:numwindows]<-fmat[negrows,numwindows:1]
				}

				# save fmat
				row.names(fmat)<-matrownames
				fmatname<-paste(dname,"/",scorename,"_",featname,suffix,".fmat",windowsize,sep="")
				cat("saving matrix to",fmatname,"\n")
				write.mat(fmat,file=fmatname)
			}
		},mc.cores=cores, mc.preschedule=FALSE)
	
	#}, mc.cores=cores2, mc.preschedule=FALSE)
	})
	return(snames)
}
