bg.hist <-
function( bgfiles , xlims = c("5%","95%") , dens=F , breaks = 100 , legend.location = "topright" , legendnames = basename(removeext(bgfiles)) , plotcolors = rainbow(length(bgfiles)) , cores = "max" ){
	
	library(parallel)
	if(cores=="max"){cores=detectCores()-1}
	
	bgnames<-basename(removeext(bgfiles))
	
	numbgs<-length(bgfiles)
	
	if(dens){
		densities<-mclapply(1:numbgs,function(x) density(as.numeric(readLines(pipe(paste("cut -f 4",bgfiles[x])))),na.rm=T),mc.cores=cores)
		xv<-lapply(1:numbgs,function(x) densities[[x]]$x)
		yv<-lapply(1:numbgs,function(x) densities[[x]]$y)
	} else{
		densities<-mclapply(1:numbgs,function(x) hist(as.numeric(readLines(pipe(paste("cut -f 4",bgfiles[x])))),plot=F, breaks=breaks),mc.cores=cores)
		xv<-lapply(1:numbgs,function(x) densities[[x]]$mids)
		yv<-lapply(1:numbgs,function(x) densities[[x]]$counts)
	}
	
	ymin<-min(unlist(yv),na.rm=TRUE)
	ymax<-max(unlist(yv),na.rm=TRUE)
	
	if( grepl( "%" , xlims[1] ) ) { xlims[1] <- min(unlist(lapply(xv,quantile, probs=as.numeric(gsub("%","",xlims[1] ) ) / 100 , na.rm=T ))) }
	if( grepl( "%" , xlims[2] ) ) { xlims[2] <- max(unlist(lapply(xv,quantile, probs=as.numeric(gsub("%","",xlims[2] ) ) / 100 , na.rm=T ))) }
	xlims<-as.numeric(xlims)

	plot(0,type="n",xlim=xlims,ylim=c(0,ymax),ylab="Density",xlab="score")
	
	for(i in 1:numbgs){
		lines(xv[[i]],yv[[i]],type="s",col=plotcolors[i],lwd=3)
	}
	
	legend(legend.location,legend=legendnames, col=plotcolors, lwd=2)
	
}
