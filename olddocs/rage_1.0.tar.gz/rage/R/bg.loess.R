bg.loess <-
function( bgfile, lspan=0.05, cores="max" ){
	library(parallel)
	library(gtools)
	if(cores=="max"){cores=detectCores()-1}
	bgname<-basename(removeext(bgfile))
	cat(bgname,": loading file\n")
	curbg<-read.tsv(bgfile)
	curbg$V4[is.infinite(curbg$V4)]<-NA
	chroms<-unique(curbg$V1)
	chroms<-mixedsort(chroms)
	cat(bgname,": reference chromosome for span will be",chroms[1],"\n")
	numchroms<-length(chroms)
	pointsperchrom<-unlist(lapply(1:numchroms, function(x) nrow(curbg[which(curbg$V1==chroms[x]),])))
	outname<-paste(bgname,"_loess",gsub("\\.","-",lspan),".bg",sep="")
	cat(bgname,": smoothing chromosome data\n")
	lscores<-mclapply(1:numchroms, function(i){
		curchrom<-curbg[which(curbg$V1==chroms[i]),]
		if(i==1){clspan=lspan} else{clspan=lspan*(pointsperchrom[i]/pointsperchrom[1])}
		goodpoints<-which(complete.cases(curchrom[,4]))
		y<-curchrom[goodpoints,4]
		x<-curchrom[goodpoints,2]
		curchrom[goodpoints,4]<-loess(y~x,span=clspan)$fitted
		curchrom
	},mc.cores=cores,mc.preschedule=FALSE)
	curbg<-do.call(rbind,lscores)
	curbg<-curbg[order(curbg$V1,curbg$V2),]
	cat(bgname,": saving file\n")
	write.tsv(curbg,file=outname)
}
