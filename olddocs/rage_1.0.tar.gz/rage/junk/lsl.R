lsl <-
function( ){system(command="ls -l")}
