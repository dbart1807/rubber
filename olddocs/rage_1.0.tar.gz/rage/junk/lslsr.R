lslsr <-
function( ){system(command="ls -lSr")}
