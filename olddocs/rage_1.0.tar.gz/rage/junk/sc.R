sc <-
function( cmd){
	system(command=paste(cmd))
}
